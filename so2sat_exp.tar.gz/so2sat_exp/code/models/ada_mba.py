# code/models/ada_mba.py
# Adaptive Multi-Branch Adapter (Ada-MBA): 空间门控 + 跨注意力融合
# 3 分支 (S2 encoder / S1 encoder / STMN pseudo-S1) → 自适应融合 → 256-d
import torch
import torch.nn as nn


class AdaMBA(nn.Module):
    """3 分支自适应融合。
    输入: feats = [f_s2, f_s1, f_stmn], 每个 (B, 256)
    输出: (B, 256)
    融合方式: 自注意力 + 跨注意力 + 门控
    """
    def __init__(self, d=256, heads=8, n_branches=3):
        super().__init__()
        self.d = d
        self.n_branches = n_branches

        # 自注意力（每分支内部）
        self.sa = nn.ModuleList([
            nn.MultiheadAttention(d, heads, batch_first=True)
            for _ in range(n_branches)
        ])

        # 跨注意力（所有对的组合）
        keys = [(i, j) for i in range(n_branches) for j in range(n_branches) if i < j]
        self.keys = keys
        self.cross = nn.ModuleDict({
            f"{i}-{j}": nn.MultiheadAttention(d, heads, batch_first=True)
            for i, j in keys
        })

        # 门控: α = σ(Wg [F_m; F_n])
        self.Wg = nn.ModuleDict({
            f"{i}-{j}": nn.Linear(2 * d, 1)
            for i, j in keys
        })

        # 融合降维: (n_branches + n_cross) 个 (B,d) → (B,d)
        total_branches = n_branches + len(keys)
        self.reduce = nn.Conv1d(total_branches, 1, 1)

    def gate(self, a, b, key):
        return torch.sigmoid(self.Wg[key](torch.cat([a, b], -1)))  # (B, 1)

    def forward(self, feats):
        """
        feats: list[n_branches] of (B, 256)
        """
        outs = []
        # 自注意力
        for i, f in enumerate(feats):
            f_in = f.unsqueeze(1)  # (B, 1, d)
            sa_out, _ = self.sa[i](f_in, f_in, f_in)
            outs.append(sa_out.squeeze(1))  # (B, d)

        # 跨注意力 + 门控
        for i, j in self.keys:
            key = f"{i}-{j}"
            ca, _ = self.cross[key](
                feats[i].unsqueeze(1), feats[j].unsqueeze(1), feats[j].unsqueeze(1)
            )
            ca = ca.squeeze(1)  # (B, d)
            a = self.gate(feats[i], feats[j], key)  # (B, 1)
            outs.append(a * ca + (1 - a) * feats[i])

        stacked = torch.stack(outs, 1)  # (B, total_branches, d)
        return self.reduce(stacked).squeeze(1)  # (B, d)

    def gate_stats(self, feats):
        """返回门权重均值（用于可视化/分析）。"""
        with torch.no_grad():
            return {
                f"{i}-{j}": float(self.gate(feats[i], feats[j], f"{i}-{j}").mean())
                for i, j in self.keys
            }

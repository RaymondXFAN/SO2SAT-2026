# code/models/stmn.py
# Spectral-to-Texture Mapping Network (STMN)
# S2(10波段) → 伪 S1(256-d)，跨模态映射
# student: MobileNetV3-Small(S2) → 256-d ; mapping: MLP → 256-d
import torch
import torch.nn as nn
from .backbone import MobileNetV3Encoder, ResidualLinear


class SpectralStudent(nn.Module):
    """Student 分支：S2 patch (B,10,32,32) → 256-d，用 MobileNetV3-Small 编码。"""
    def __init__(self, out=256, freeze_bn=5):
        super().__init__()
        self.encoder = MobileNetV3Encoder(in_channels=10, out_dim=out)
        self.freeze_bn = freeze_bn
        self._bn_frozen = False

    def forward(self, x):
        return self.encoder(x)  # (B, 256)

    def maybe_freeze_bn(self, epoch):
        """前 freeze_bn 个 epoch 冻结 BN（预训练权重稳定）。"""
        if epoch < self.freeze_bn and not self._bn_frozen:
            for m in self.encoder.modules():
                if isinstance(m, nn.BatchNorm2d):
                    m.eval()
                    m.requires_grad_(False)
            self._bn_frozen = True
        elif epoch >= self.freeze_bn and self._bn_frozen:
            for m in self.encoder.modules():
                if isinstance(m, nn.BatchNorm2d):
                    m.requires_grad_(True)
            self._bn_frozen = False


class MappingMLP(nn.Module):
    """3 层 MLP: 256 → 512 → 256 → 256, residual + BN + ReLU。"""
    def __init__(self, in_f=256, h=512, out=256):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_f, h), nn.BatchNorm1d(h), nn.ReLU(),
            ResidualLinear(h),
            nn.Linear(h, out), nn.BatchNorm1d(out), nn.ReLU(),
        )

    def forward(self, f):
        return self.net(f)  # (B, 256)


class STMN(nn.Module):
    """STMN: S2 → 伪 S1 特征。
    Student(S2) → MappingMLP → F_hat（预测的 S1 特征表示）
    用于跨模态映射：S2 的 10 波段光谱信息 → S1 的 SAR 特征空间
    """
    def __init__(self, dim=256, mlp=(512, 256, 256), lambda_reg=1e-4):
        super().__init__()
        self.student = SpectralStudent(out=dim)
        self.map = MappingMLP(in_f=dim, h=mlp[0], out=dim)
        self.lambda_reg = lambda_reg

    def forward(self, s2):
        """推断模式：S2 → 伪 S1 特征 (256-d)"""
        f_s2 = self.student(s2)
        f_hat = self.map(f_s2)
        return f_hat  # (B, 256)

    def loss(self, f_hat, f_s1):
        """重建损失：||F_hat - F_s1||² + λ||θ_m||²
        f_hat: 伪 S1 特征; f_s1: 真实 S1 特征（来自 S1 encoder）
        """
        recon = (f_hat - f_s1).pow(2).mean()
        reg = sum(p.pow(2).sum() for p in self.map.parameters())
        return recon + self.lambda_reg * reg

    def maybe_freeze_bn(self, epoch):
        self.student.maybe_freeze_bn(epoch)

# code/prepare_so2sat.py
# So2Sat LCZ42 数据预处理：h5 → 子集采样 → 归一化 → .pt
# ★★★ 核心修改 v2：内存高效版！不加载整个49GB training.h5！
# ★★★ 策略：先只读labels(极小) → 算分层索引 → 只加载需要的5000样本
# ★★★ 所有缓存重定向到数据盘 /root/autodl-tmp/.cache/
import os
import json
import numpy as np
import torch
from pathlib import Path

# ── ★★★ 缓存重定向（必须在 import datasets 之前！） ──
import sys; sys.path.insert(0, str(Path(__file__).resolve().parent))
CACHE_ROOT = Path("/root/autodl-tmp/.cache")
CACHE_ROOT.mkdir(parents=True, exist_ok=True)
os.environ["HF_HOME"]           = str(CACHE_ROOT / "huggingface")
os.environ["HF_DATASETS_CACHE"]  = str(CACHE_ROOT / "huggingface/datasets")
os.environ["HF_MODULES_CACHE"]  = str(CACHE_ROOT / "huggingface/modules")
os.environ["HF_ENDPOINT"]       = os.environ.get("HF_ENDPOINT", "https://hf-mirror.com")

from config import CFG, DATA, RAW, ROOT


def check_disk_space():
    """★ 检查数据盘和系统盘空间，避免爆盘"""
    print("=" * 60)
    print("★ 磁盘空间检查（★ 极其重要！）")
    print("=" * 60)

    tmp_info = os.popen("df -h /root/autodl-tmp").read().strip()
    print(f"  数据盘 /root/autodl-tmp:\n  {tmp_info}")

    root_info = os.popen("df -h /root").read().strip()
    print(f"  系统盘 /root:\n  {root_info}")

    # 检查内存
    mem_info = os.popen("free -h").read().strip()
    print(f"\n  内存状态:\n  {mem_info}")

    return True


def check_memory():
    """★ 检查系统可用内存，确保足够处理数据"""
    mem_info = os.popen("free -m").read().strip()
    lines = mem_info.split('\n')
    avail_mb = 0
    for line in lines:
        if 'Mem:' in line:
            parts = line.split()
            # available 列（第7列，有些系统是第6列）
            for i, p in enumerate(parts):
                if 'available' not in mem_info.lower():
                    # 旧格式：total used free shared buff/cache available
                    if i == 6:  # available
                        try: avail_mb = int(p)
                        except: pass
                else:
                    if i >= 3:
                        try: avail_mb = max(avail_mb, int(p))
                        except: pass

    print(f"  ★ 可用内存: ~{avail_mb}MB (~{avail_mb/1024:.1f}GB)")
    if avail_mb < 4000:  # < 4GB
        print(f"  ⚠️ 可用内存较少，将使用内存高效模式（只加载子集）")
    return avail_mb


def stratified_subset(labels, n, seed=42):
    """分层采样：确保各类别比例大致均匀
    labels: (N,) numpy array of class labels
    n: 需要采样的样本数
    返回: 索引列表
    """
    rng = np.random.RandomState(seed)
    unique_labels = np.unique(labels)
    n_per_class = max(1, n // len(unique_labels))
    idxs = []
    for lbl in unique_labels:
        lbl_idx = np.where(labels == lbl)[0]
        if len(lbl_idx) >= n_per_class:
            chosen = rng.choice(lbl_idx, n_per_class, replace=False)
        else:
            chosen = rng.choice(lbl_idx, len(lbl_idx), replace=False)
        idxs.extend(chosen.tolist())
    if len(idxs) < n:
        remaining = list(set(range(len(labels))) - set(idxs))
        if remaining:
            extra = rng.choice(remaining, n - len(idxs), replace=False)
            idxs.extend(extra.tolist())
    idxs = sorted(idxs[:n])  # ★ 排序索引！h5py按排序索引读取更快
    return idxs


def load_h5_labels(path):
    """★ 内存高效：只读 labels（极小！），不读 S1/S2
    ★★★ So2Sat 的 label 是 one-hot 编码 (N, 17)，不是整数！
    ★★★ 必须用 np.argmax 转成整数 0-16，否则类别数=2（只看到0和1）
    """
    import h5py
    print(f"  ★ 只读 labels: {path} ...")
    with h5py.File(str(path), 'r') as f:
        label_raw = np.array(f['label'])
        print(f"    label 原始 shape: {label_raw.shape}, dtype: {label_raw.dtype}")
        # ★★★ So2Sat label 是 one-hot: (N, 17) → 用 argmax 转成整数 (N,)
        if label_raw.ndim > 1:
            label = np.argmax(label_raw, axis=1)
            print(f"    ★ one-hot → argmax 转换: (N,17) → (N,) 整数 0-16")
        else:
            label = label_raw
    n_classes = len(np.unique(label))
    print(f"    样本数: {len(label)}, 类别数: {n_classes} {'✓ 17类' if n_classes==17 else '⚠️ 异常！'}")
    print(f"    label range: {label.min()} ~ {label.max()}")
    print(f"    内存占用: ~{label.nbytes / 1e6:.1f}MB（极小！）")
    del label_raw  # 释放原始 label 内存
    return label


def load_h5_subset(path, indices):
    """★ 内存高效：只加载指定索引的 S1/S2 数据
    indices: 列表/数组，指定需要哪些样本
    ★★★ h5py 要求索引必须是 sorted + unique + numpy array（严格递增，不能重复）
    ★★★ 先 inspect h5 keys，然后排序去重索引再读取
    """
    import h5py
    # ★★★ 确保索引是 sorted unique numpy array（h5py 硬性要求！）
    indices = np.sort(np.unique(np.asarray(indices)))
    n = len(indices)
    print(f"  ★ 只加载 {n} 个样本: {path} ...")
    print(f"    索引范围: {indices[0]} ~ {indices[-1]}")
    with h5py.File(str(path), 'r') as f:
        # ★ 先 inspect h5 文件的 keys 和 shape（调试用）
        keys = list(f.keys())
        print(f"    h5 keys: {keys}")
        for k in keys:
            ds = f[k]
            print(f"    {k}: shape={ds.shape}, dtype={ds.dtype}")

        # ★ 关键：h5py fancy indexing 只读指定索引的数据
        # 49GB 文件只读 5000 个样本 → 内存占用约 ~0.2GB（而不是 ~40GB！）
        s1 = np.array(f['sen1'][indices])    # (n, 32, 32, 8)
        s2 = np.array(f['sen2'][indices])    # (n, 32, 32, 10)
    print(f"    S1 shape: {s1.shape}, dtype: {s1.dtype}")
    print(f"    S2 shape: {s2.shape}, dtype: {s2.dtype}")
    mem_mb = (s1.nbytes + s2.nbytes) / 1e6
    print(f"    内存占用: ~{mem_mb:.1f}MB")
    return s1, s2, indices  # ★ 返回实际用的索引（去重后可能少于 n）


def preprocess_from_ftp_efficient():
    """★ 内存高效版预处理流程（★ 推荐！）
    
    旧版问题：load_h5() 把整个 49GB training.h5 加载到内存 → OOM 崩盘！
    新版策略：
      Step 1: 只读 labels（~0.35MB，极小）→ 算分层索引
      Step 2: 只加载 5000/1000/1000 个样本的 S1/S2（~200MB）
      Step 3: 归一化 + 保存
    
    内存峰值：~1GB（vs 旧版 ~40GB → 崩盘）
    """
    print("=" * 60)
    print("★ 内存高效版预处理（★ 不会 OOM！）")
    print("★ 策略：先读 labels → 算索引 → 只加载子集样本")
    print("=" * 60)

    import h5py
    train_h5 = RAW / "training.h5"
    val_h5 = RAW / "validation.h5"
    test_h5 = RAW / "testing.h5"

    # ★ Step 1：只读 labels（极小！总共不到 1MB）
    print("\n── Step 1: 只读 labels（极小，不占内存）──")
    train_label = load_h5_labels(train_h5)
    val_label = load_h5_labels(val_h5)
    test_label = load_h5_labels(test_h5)

    # ★ Step 2：分层采样 → 计算索引
    print("\n── Step 2: 分层采样 → 计算索引 ──")
    n_train = CFG["n_train"]   # 5000
    n_val = CFG["n_val"]       # 1000
    n_test = CFG["n_test"]     # 1000

    train_idx = stratified_subset(train_label, n_train, seed=CFG["seed"])
    val_idx = stratified_subset(val_label, n_val, seed=CFG["seed"] + 1)
    test_idx = stratified_subset(test_label, n_test, seed=CFG["seed"] + 2)

    print(f"  训练子集: {len(train_idx)} 样本 (从 {len(train_label)} 中采样)")
    print(f"  验证子集: {len(val_idx)} 样本 (从 {len(val_label)} 中采样)")
    print(f"  测试子集: {len(test_idx)} 样本 (从 {len(test_label)} 中采样)")

    # ★ Step 3：只加载需要的样本（内存峰值 ~200MB）
    print("\n── Step 3: 只加载子集样本（★ 内存高效！）──")
    print("  ★ 49GB training.h5 只读 5000 个样本 → ~0.2GB，不会 OOM！")

    train_s1, train_s2, train_idx_actual = load_h5_subset(train_h5, train_idx)
    val_s1, val_s2, val_idx_actual = load_h5_subset(val_h5, val_idx)
    test_s1, test_s2, test_idx_actual = load_h5_subset(test_h5, test_idx)

    # ★ 用实际索引（去重后）取对应的 labels
    train_label_sub = train_label[train_idx_actual]
    val_label_sub = val_label[val_idx_actual]
    test_label_sub = test_label[test_idx_actual]

    print(f"\n  ★ 实际样本数: train={len(train_idx_actual)}, val={len(val_idx_actual)}, test={len(test_idx_actual)}")

    # ★ Step 4：归一化 + 保存
    print("\n── Step 4: 归一化 + 保存 ──")
    do_normalize_and_save(
        train_s1, train_s2, train_label_sub,
        val_s1, val_s2, val_label_sub,
        test_s1, test_s2, test_label_sub,
    )


def do_normalize_and_save(train_s1, train_s2, train_label,
                           val_s1, val_s2, val_label,
                           test_s1, test_s2, test_label):
    """归一化 + 构建 .pt 文件 → 保存到数据盘"""

    DATA.mkdir(parents=True, exist_ok=True)

    # ── 归一化统计（仅用训练集） ──
    print("  计算 Z-score 归一化统计（仅用训练子集）...")
    s1_mean = train_s1.astype(np.float32).mean(axis=(0, 1, 2))  # (8,)
    s1_std = train_s1.astype(np.float32).std(axis=(0, 1, 2)) + 1e-8
    s2_mean = train_s2.astype(np.float32).mean(axis=(0, 1, 2))  # (10,)
    s2_std = train_s2.astype(np.float32).std(axis=(0, 1, 2)) + 1e-8

    print(f"  S1 归一化: mean={s1_mean[:3].round(2)}, std={s1_std[:3].round(2)}")
    print(f"  S2 归一化: mean={s2_mean[:3].round(3)}, std={s2_std[:3].round(3)}")

    stats = {
        "s1_mean": s1_mean.tolist(), "s1_std": s1_std.tolist(),
        "s2_mean": s2_mean.tolist(), "s2_std": s2_std.tolist(),
        "n_train": len(train_label), "n_val": len(val_label), "n_test": len(test_label),
    }

    # ── 构建样本列表 ──
    def build_samples(s2_all, s1_all, labels_all):
        """构建样本列表，归一化，转 channel-first"""
        samples = []
        n = len(labels_all)
        for i in range(n):
            # S2: (32,32,10) → Z-score → (10,32,32)
            s2_patch = s2_all[i].astype(np.float32)
            s2_norm = (s2_patch - s2_mean) / s2_std
            s2_ch = np.transpose(s2_norm, (2, 0, 1))

            # S1: (32,32,8) → Z-score → (8,32,32)
            s1_patch = s1_all[i].astype(np.float32)
            s1_norm = (s1_patch - s1_mean) / s1_std
            s1_ch = np.transpose(s1_norm, (2, 0, 1))

            samples.append({
                "s2": s2_ch,
                "s1": s1_ch,
                "label": int(labels_all[i]),
                "city_idx": 0,
            })
        return samples

    print("  构建训练集样本...")
    train_samples = build_samples(train_s2, train_s1, train_label)
    print("  构建验证集样本...")
    val_samples = build_samples(val_s2, val_s1, val_label)
    print("  构建测试集样本...")
    test_samples = build_samples(test_s2, test_s1, test_label)

    # ── 保存到数据盘 ──
    train_pt = DATA / "train.pt"
    val_pt = DATA / "val.pt"
    test_pt = DATA / "test.pt"
    stats_json = DATA / "stats.json"

    torch.save(train_samples, train_pt)
    torch.save(val_samples, val_pt)
    torch.save(test_samples, test_pt)
    json.dump(stats, open(stats_json, "w"), indent=2)

    print(f"\n✅ 预处理完成！所有文件在数据盘 {DATA}")
    print(f"  {train_pt}: {len(train_samples)} 样本 ({train_pt.stat().st_size / 1e6:.1f}MB)")
    print(f"  {val_pt}: {len(val_samples)} 样本 ({val_pt.stat().st_size / 1e6:.1f}MB)")
    print(f"  {test_pt}: {len(test_samples)} 样本 ({test_pt.stat().st_size / 1e6:.1f}MB)")
    print(f"  {stats_json}: 归一化统计")


def download_hf():
    """★ 方式②：HuggingFace 下载（备用，需要 datasets 库）
    ⚠️ HF 缓存已重定向到数据盘
    """
    print("=" * 60)
    print("★ 方式②：HuggingFace 下载（缓存已重定向到数据盘）")
    print("=" * 60)
    print(f"  HF 缓存路径: {os.environ.get('HF_HOME', '未设置！')}")

    from datasets import load_dataset
    ds = load_dataset('zhu-xlab/So2Sat-LCZ42')
    print(f"下载完成！训练集 {len(ds['train'])} 样本")
    return ds


def preprocess_from_hf(ds):
    """HF 方式的数据提取 + 预处理"""
    print("  从 HuggingFace 数据集提取...")
    train_s2 = np.stack([np.array(x['s2']) for x in ds['train']])
    train_s1 = np.stack([np.array(x['s1']) for x in ds['train']])
    train_label = np.array([x['label'] for x in ds['train']])

    val_key = 'validation' if 'validation' in ds else 'train'
    val_s2 = np.stack([np.array(x['s2']) for x in ds[val_key]])
    val_s1 = np.stack([np.array(x['s1']) for x in ds[val_key]])
    val_label = np.array([x['label'] for x in ds[val_key]])

    test_key = 'testing' if 'testing' in ds else 'test' if 'test' in ds else 'train'
    test_s2 = np.stack([np.array(x['s2']) for x in ds[test_key]])
    test_s1 = np.stack([np.array(x['s1']) for x in ds[test_key]])
    test_label = np.array([x['label'] for x in ds[test_key]])

    # 子集采样
    train_idx = stratified_subset(train_label, CFG["n_train"], seed=CFG["seed"])
    val_idx = stratified_subset(val_label, CFG["n_val"], seed=CFG["seed"] + 1)
    test_idx = stratified_subset(test_label, CFG["n_test"], seed=CFG["seed"] + 2)

    train_s1_sub = train_s1[train_idx]
    train_s2_sub = train_s2[train_idx]
    val_s1_sub = val_s1[val_idx]
    val_s2_sub = val_s2[val_idx]
    test_s1_sub = test_s1[test_idx]
    test_s2_sub = test_s2[test_idx]

    do_normalize_and_save(
        train_s1_sub, train_s2_sub, train_label[train_idx],
        val_s1_sub, val_s2_sub, val_label[val_idx],
        test_s1_sub, test_s2_sub, test_label[test_idx],
    )

    # HF 缓存清理
    print(f"\n★ 清理 HF 缓存释放数据盘空间:")
    hf_cache = CACHE_ROOT / "huggingface/datasets"
    if hf_cache.exists():
        import shutil
        shutil.rmtree(hf_cache, ignore_errors=True)
        print(f"  ✓ 已删除 {hf_cache}")


def main():
    """主流程：磁盘检查 → 内存检查 → 预处理 → 保存"""
    print("★ So2Sat LCZ42 数据准备流程 v2（内存高效版）")
    print(f"★ 项目根目录: {ROOT}（数据盘 /root/autodl-tmp）")
    print(f"★ 数据目录: {DATA}（数据盘）")
    print(f"★ 缓存目录: {CACHE_ROOT}（数据盘，★ 不在系统盘！）")

    # ★ 第一步：检查磁盘空间
    if not check_disk_space():
        print("✗ 数据盘空间不足！")
        return

    # ★ 第二步：检查内存
    check_memory()

    # ★ 第三步：检查是否已有预处理好的数据
    if (DATA / "train.pt").exists():
        print(f"\n⚠️ train.pt 已存在！如需重新预处理，请先删除:")
        print(f"  rm {DATA}/*.pt {DATA}/stats.json")
        return

    # ★ 第四步：预处理
    # ★ 检查 FTP 文件是否存在
    ftp_files = [RAW / "training.h5", RAW / "validation.h5", RAW / "testing.h5"]
    all_exist = all(f.exists() for f in ftp_files)

    if all_exist:
        # ★ FTP 方式（推荐！内存高效版）
        print("\n★ FTP h5 文件已存在 → 使用内存高效版预处理")
        print("★ 不会加载整个 49GB 文件到内存！")
        preprocess_from_ftp_efficient()
    else:
        # HF 方式（备用）
        missing = [f.name for f in ftp_files if not f.exists()]
        print(f"\n✗ FTP 文件缺失: {missing}")
        print("→ 尝试 HuggingFace 方式...")
        try:
            ds = download_hf()
            preprocess_from_hf(ds)
        except Exception as e:
            print(f"\n✗ 所有下载方式都失败: {e}")
            print("请手动下载 FTP 文件到 " + str(RAW))


if __name__ == "__main__":
    main()

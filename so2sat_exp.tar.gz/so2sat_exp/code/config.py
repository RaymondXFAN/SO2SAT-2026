# code/config.py
# So2Sat LCZ42 实验 — 所有路径 / 超参 / 随机种子集中管理
# ★★★ 关键：所有缓存必须重定向到数据盘 /root/autodl-tmp/.cache/
# ★★★ 系统盘 /root 只有 30G，HF 缓存 7GB+ 直接爆盘！
import os
from pathlib import Path

# ── ★★★ 第一步：缓存重定向（必须在所有 import 之前！） ──
# 把 pip / HF / torch 等所有缓存指向数据盘，避免撑爆 30G 系统盘
CACHE_ROOT = Path("/root/autodl-tmp/.cache")
CACHE_ROOT.mkdir(parents=True, exist_ok=True)

os.environ["XDG_CACHE_HOME"]   = str(CACHE_ROOT)           # 通用缓存（catch-all）
os.environ["HF_HOME"]          = str(CACHE_ROOT / "huggingface")  # HF 数据集缓存（★最关键！7GB+）
os.environ["HF_DATASETS_CACHE"] = str(CACHE_ROOT / "huggingface/datasets")
os.environ["HF_MODULES_CACHE"]  = str(CACHE_ROOT / "huggingface/modules")
os.environ["PIP_CACHE_DIR"]    = str(CACHE_ROOT / "pip")    # pip 缓存
os.environ["TORCH_HOME"]       = str(CACHE_ROOT / "torch")  # torch hub / 模型权重缓存
os.environ["HF_ENDPOINT"]      = os.environ.get("HF_ENDPOINT", "https://hf-mirror.com")

# ── 项目根目录 ──（数据盘上）
ROOT = Path(os.environ.get(
    "SO2SAT_ROOT",
    "/root/autodl-tmp/so2sat_exp"      # ★ AutoDL 数据盘路径
))

# ── 数据路径 ──（全部在数据盘上）
DATA = ROOT / "data"                     # .pt 文件存这里
RAW  = DATA / "raw"                      # 原始 h5 文件存这里
OUT  = ROOT / "out"                      # 结果输出
OUT.mkdir(parents=True, exist_ok=True)

# ── 核心超参数 ──
CFG = dict(
    # 硬件
    device="cuda" if __import__("torch").cuda.is_available() else "cpu",
    gpu_batch_size=64,          # RTX 4090: batch=64 很稳
    cpu_batch_size=16,          # CPU fallback

    # 数据
    n_classes=17,               # So2Sat LCZ42: 17 个本地气候区类型
    n_modalities=2,             # S2 + S1（STMN 从 S2 推断伪 S1 作为第3路输入）
    patch=32,                   # 32×32 像素（So2Sat 原始分辨率）
    s2_bands=10,                # Sentinel-2: B2-B8, B8a, B11, B12
    s1_bands=8,                 # Sentinel-1: VV/VH 等 8 通道
    n_train=5000,               # 子集：5000 训练样本
    n_val=1000,                 # 子集：1000 验证样本
    n_test=1000,                # 子集：1000 测试样本

    # 训练
    epochs=50,
    optimizer="AdamW",
    lr=1e-3,
    weight_decay=1e-4,
    scheduler="cosine",
    warmup_epochs=5,
    early_stop_patience=10,
    monitor="val_oa",           # 监控 Overall Accuracy
    grad_clip=1.0,
    seed=42,

    # STMN
    stmn=dict(
        dim=256,
        mlp=(512, 256, 256),
        lambda_reg=1e-4,
        noise_sigma=0.01,
        bn_freeze_epochs=5,
    ),

    # Ada-MBA
    ada_mba=dict(
        d=256,
        heads=8,
        n_branches=3,            # S2 encoder + S1 encoder + STMN pseudo-S1
    ),

    # Domain Adaptation（跨城市迁移）
    da=dict(adv_weight=0.5, lambda_grid=(0.1, 0.5, 1.0)),
)

# ── 批量大小自动适配 ──
CFG["batch_size"] = CFG["gpu_batch_size"] if CFG["device"] == "cuda" else CFG["cpu_batch_size"]

# ── LCZ42 类名映射 ──
LCZ_NAMES = [
    "Compact high-rise",       # 0
    "Compact mid-rise",        # 1
    "Compact low-rise",        # 2
    "Open high-rise",          # 3
    "Open mid-rise",           # 4
    "Open low-rise",           # 5
    "Lightweight low-rise",    # 6
    "Large low-rise",          # 7
    "Sparsely built",          # 8
    "Heavy industry",          # 9
    "Dense trees",             # 10
    "Scattered trees",         # 11
    "Bush/scrub",              # 12
    "Low plants",              # 13
    "Bare rock/paved",         # 14
    "Bare soil/sand",          # 15
    "Water",                   # 16
]

# code/datasets.py
# So2Sat LCZ42 PyTorch Dataset + DataLoader
import torch
from torch.utils.data import Dataset, DataLoader
from pathlib import Path
import sys; sys.path.insert(0, str(Path(__file__).resolve().parent))
from config import CFG, DATA, LCZ_NAMES


class So2SatDataset(Dataset):
    """加载预处理好的 .pt 文件；每个样本 dict: s2(B,10,32,32), s1(B,8,32,32), label, city_idx."""
    def __init__(self, pt_path):
        self.samples = torch.load(pt_path, weights_only=False)

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, i):
        s = self.samples[i]
        return (
            torch.as_tensor(s["s2"], dtype=torch.float32),   # (10, 32, 32)
            torch.as_tensor(s["s1"], dtype=torch.float32),   # (8, 32, 32)
            torch.as_tensor(s["label"], dtype=torch.long),   # int 0-16
            int(s.get("city_idx", 0)),                        # 域划分用
        )


def make_loader(pt_path, batch_size=None, shuffle=False):
    """快捷创建 DataLoader"""
    bs = batch_size or CFG["batch_size"]
    num_workers = 4 if CFG["device"] == "cuda" else 0
    return DataLoader(
        So2SatDataset(pt_path),
        batch_size=bs,
        shuffle=shuffle,
        num_workers=num_workers,
        drop_last=False,
        pin_memory=CFG["device"] == "cuda",
    )

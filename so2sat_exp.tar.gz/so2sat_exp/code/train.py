# code/train.py
# So2Sat LCZ42 主训练循环 + 指标 (OA/AA/Kappa/F1) + 早停
# ★ 数据在 /root/autodl-tmp/so2sat_exp/data/（数据盘）
# ★ GPU: RTX 4090, batch_size=64, 约30-50分钟/50epoch
import os
import csv
import time
import numpy as np
import torch
import torch.nn as nn
from pathlib import Path
import sys; sys.path.insert(0, str(Path(__file__).resolve().parent))
from config import CFG, DATA, OUT, ROOT, LCZ_NAMES
from datasets import So2SatDataset, make_loader
from models import MobileNetV3Encoder, STMN, AdaMBA

# ── 指标 ──
def overall_accuracy(y_true, y_pred):
    return 100.0 * np.mean(y_true == y_pred)

def average_accuracy(y_true, y_pred, n_classes=17):
    """各类别 accuracy 的均值 (AA)"""
    accs = []
    for c in range(n_classes):
        mask = y_true == c
        if mask.sum() > 0:
            accs.append(np.mean(y_pred[mask] == c))
        else:
            accs.append(0.0)
    return 100.0 * np.mean(accs)

def kappa_coefficient(y_true, y_pred, n_classes=17):
    """Cohen's Kappa"""
    cm = np.zeros((n_classes, n_classes))
    for t, p in zip(y_true, y_pred):
        cm[int(t), int(p)] += 1
    n = cm.sum()
    po = cm.trace() / n
    pe = sum(cm[i].sum() * cm[:, i].sum() for i in range(n_classes)) / (n * n)
    return 100.0 * (po - pe) / (1 - pe) if (1 - pe) != 0 else 0.0

def macro_f1(y_true, y_pred, n_classes=17):
    from sklearn.metrics import f1_score
    return 100.0 * f1_score(y_true, y_pred, average='macro', labels=list(range(n_classes)), zero_division=0)

def compute_metrics(y_true, y_pred, n_classes=17):
    oa = overall_accuracy(y_true, y_pred)
    aa = average_accuracy(y_true, y_pred, n_classes)
    kp = kappa_coefficient(y_true, y_pred, n_classes)
    f1 = macro_f1(y_true, y_pred, n_classes)
    return dict(oa=oa, aa=aa, kappa=kp, f1=f1)


# ── 主模型 ──
class So2SatNet(nn.Module):
    """Proposed: S2+S1 双模态 → MobileNetV3-Small 编码 → STMN 跨模态 → Ada-MBA 融合 → 17类分类。
    总参数 ~3.3M（比 ResNet-18 方案小 3 倍）。
    """
    def __init__(self):
        super().__init__()
        self.enc_s2 = MobileNetV3Encoder(in_channels=CFG["s2_bands"], out_dim=256)
        self.enc_s1 = MobileNetV3Encoder(in_channels=CFG["s1_bands"], out_dim=256)
        self.stmn = STMN(dim=256, mlp=(512, 256, 256))
        self.fuse = AdaMBA(d=256, heads=8, n_branches=3)
        self.head = nn.Linear(256, CFG["n_classes"])

    def forward(self, s2, s1):
        # S2 encoder → 256-d
        f_s2 = self.enc_s2(s2)
        # S1 encoder → 256-d
        f_s1 = self.enc_s1(s1)
        # STMN: S2 → pseudo-S1 (256-d)
        f_stmn = self.stmn(s2)
        # Ada-MBA 融合 3 个分支
        fused = self.fuse([f_s2, f_s1, f_stmn])
        # 分类头
        return self.head(fused), f_stmn, f_s1


def train_one_epoch(model, loader, opt, sched, crit, device):
    model.train()
    total_loss = 0
    for s2, s1, y, _ in loader:
        s2, s1, y = s2.to(device), s1.to(device), y.to(device)
        opt.zero_grad()
        logits, f_stmn, f_s1 = model(s2, s1)
        # 主分类损失
        loss_cls = crit(logits, y)
        # STMN 重建损失（辅助）
        loss_stmn = CFG["stmn"]["lambda_reg"] * model.stmn.loss(f_stmn, f_s1)
        loss = loss_cls + loss_stmn
        loss.backward()
        nn.utils.clip_grad_norm_(model.parameters(), CFG["grad_clip"])
        opt.step()
        sched.step()
        total_loss += loss.item()
    return total_loss / len(loader)


@torch.no_grad()
def evaluate(model, loader, device):
    model.eval()
    Yt, Yp = [], []
    for s2, s1, y, _ in loader:
        s2, s1 = s2.to(device), s1.to(device)
        logits, _, _ = model(s2, s1)
        Yt += y.tolist()
        Yp += logits.argmax(1).cpu().tolist()
    return compute_metrics(np.array(Yt), np.array(Yp))


def main():
    """主训练流程"""
    print("=" * 60)
    print("★ So2Sat LCZ42 训练")
    print("=" * 60)
    print(f"  项目根目录: {ROOT}")
    print(f"  数据目录: {DATA}")
    print(f"  输出目录: {OUT}")
    print(f"  设备: {CFG['device']}")
    print(f"  GPU型号: {torch.cuda.get_device_name(0) if CFG['device']=='cuda' else 'CPU'}")
    print(f"  批量大小: {CFG['batch_size']}")
    print(f"  类别数: {CFG['n_classes']}")
    print(f"  训练轮数: {CFG['epochs']}")

    device = CFG["device"]
    model = So2SatNet().to(device)
    n_params = sum(p.numel() for p in model.parameters())
    print(f"  模型参数: {n_params / 1e6:.2f}M")

    # 加载数据
    train_pt = DATA / "train.pt"
    val_pt = DATA / "val.pt"
    test_pt = DATA / "test.pt"

    if not train_pt.exists():
        print(f"\n✗ {train_pt} 不存在！请先运行 prepare_so2sat.py")
        return

    tr_loader = make_loader(str(train_pt), shuffle=True)
    va_loader = make_loader(str(val_pt), shuffle=False)
    te_loader = make_loader(str(test_pt), shuffle=False)

    # 训练配置
    opt = torch.optim.AdamW(model.parameters(), lr=CFG["lr"], weight_decay=CFG["weight_decay"])
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=CFG["epochs"])
    crit = nn.CrossEntropyLoss()

    best_oa, wait = -1, 0
    log_rows = []
    t0 = time.time()

    for ep in range(1, CFG["epochs"] + 1):
        loss = train_one_epoch(model, tr_loader, opt, sched, crit, device)
        vm = evaluate(model, va_loader, device)
        tm = evaluate(model, te_loader, device)

        elapsed = time.time() - t0
        print(f"  Epoch {ep:3d}/{CFG['epochs']} | loss={loss:.4f} | "
              f"val OA={vm['oa']:.2f}% AA={vm['aa']:.2f}% Kappa={vm['kappa']:.1f}% F1={vm['f1']:.2f}% | "
              f"test OA={tm['oa']:.2f}% | {elapsed/60:.1f}min")

        log_rows.append({
            "epoch": ep, "loss": loss,
            "val_oa": vm["oa"], "val_aa": vm["aa"], "val_kappa": vm["kappa"], "val_f1": vm["f1"],
            "test_oa": tm["oa"], "test_aa": tm["aa"], "test_kappa": tm["kappa"], "test_f1": tm["f1"],
            "elapsed_min": elapsed / 60,
        })

        # 早停
        if vm["oa"] > best_oa:
            best_oa, wait = vm["oa"], 0
            # 保存最佳模型
            torch.save(model.state_dict(), OUT / "best_model.pt")
        else:
            wait += 1
            if wait >= CFG["early_stop_patience"]:
                print(f"\n★ 早停触发！最佳 val OA = {best_oa:.2f}%")
                break

        # STMN BN 解冻
        model.stmn.maybe_freeze_bn(ep)

    # ── 最终评估 ──
    model.load_state_dict(torch.load(OUT / "best_model.pt", weights_only=True))
    final = evaluate(model, te_loader, device)
    print(f"\n{'=' * 60}")
    print(f"★ 最终结果 (best model on test set)")
    print(f"  OA  = {final['oa']:.2f}%")
    print(f"  AA  = {final['aa']:.2f}%")
    print(f"  Kappa = {final['kappa']:.1f}%")
    print(f"  F1  = {final['f1']:.2f}%")
    print(f"{'=' * 60}")

    # ── 保存结果 ──
    # 训练日志
    log_path = OUT / "train_log.csv"
    with open(log_path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=log_rows[0].keys())
        w.writeheader()
        w.writerows(log_rows)
    print(f"  训练日志 → {log_path}")

    # 主结果表
    main_path = OUT / "table2_main.csv"
    with open(main_path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["metric", "value"])
        for k, v in final.items():
            w.writerow([k, f"{v:.2f}"])
    print(f"  主结果 → {main_path}")

    # 逐类 OA
    from sklearn.metrics import confusion_matrix
    model.eval()
    Yt, Yp = [], []
    with torch.no_grad():
        for s2, s1, y, _ in te_loader:
            s2, s1 = s2.to(device), s1.to(device)
            logits, _, _ = model(s2, s1)
            Yt += y.tolist()
            Yp += logits.argmax(1).cpu().tolist()
    cm = confusion_matrix(Yt, Yp, labels=list(range(17)))

    classwise_path = OUT / "table5_classwise.csv"
    with open(classwise_path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["class_id", "class_name", "test_samples", "accuracy"])
        for c in range(17):
            n_samples = cm[c].sum()
            acc = cm[c, c] / n_samples if n_samples > 0 else 0
            w.writerow([c, LCZ_NAMES[c], n_samples, f"{100 * acc:.2f}%"])
    print(f"  逐类OA → {classwise_path}")

    # 混淆矩阵
    cm_path = OUT / "confusion_matrix.csv"
    with open(cm_path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["true"] + LCZ_NAMES)
        for i in range(17):
            w.writerow([LCZ_NAMES[i]] + [cm[i, j] for j in range(17)])
    print(f"  混淆矩阵 → {cm_path}")

    print(f"\n✅ 训练完成！总耗时 {(time.time() - t0) / 60:.1f} 分钟")
    print(f"  ⚠️ 下载结果后请关机停计费！")


if __name__ == "__main__":
    main()

# So2Sat LCZ42 实验 — 云端 GPU 版（AutoDL RTX 4090）
# 数据盘: /root/autodl-tmp (100G)
# ★ 所有数据和结果存储在数据盘，关机后数据不丢失！

本项目在 AutoDL 云端 GPU 上运行 So2Sat LCZ42 本地气候区分类实验。

## 快速开始

```bash
# 1. 进入项目目录（数据盘）
cd /root/autodl-tmp/so2sat_exp

# 2. 设置 HF 镜像（每次开新终端都要设置！）
export HF_ENDPOINT=https://hf-mirror.com

# 3. 下载数据 + 预处理
python code/prepare_so2sat.py

# 4. 开始训练
python code/train.py

# 5. 下载结果到本机后关机停计费
```

## 硬件配置

| 项目 | 配置 |
|------|------|
| GPU | NVIDIA RTX 4090 (24GB VRAM) |
| CUDA Driver | 570.124.04 |
| CUDA Version | 12.8 |
| PyTorch | cu124 (CUDA runtime 12.4) |
| 数据盘 | /root/autodl-tmp (100G) |
| 系统盘 | /root (30G，不要放数据！) |

## 模型架构

- **Backbone**: MobileNetV3-Small (~2.5M 参数)
- **STMN**: S2→S1 跨模态映射
- **Ada-MBA**: S2+S1+STMN 三分支自适应融合
- **总参数**: ~3.3M
- **分类**: 17 类 LCZ (Local Climate Zones)

## ⚠️ 重要提醒

1. **所有数据放在 /root/autodl-tmp/ 下**（数据盘，关机不丢失）
2. **不要放在 /root/ 下**（系统盘，关机后重置）
3. **跑完必须关机停计费**！结果先下载回本机
4. **每次开终端重新设置 HF 镜像**
